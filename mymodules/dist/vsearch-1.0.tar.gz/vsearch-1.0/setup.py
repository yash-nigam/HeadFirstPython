from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.0',
    description = 'Head First Python Search tools',
    author = 'yash',
    author_email = 'yashniga@gmail.com',
    url = 'gmail.com',
    py_modules=['vsearch']
)
